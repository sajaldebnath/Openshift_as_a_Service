﻿[CmdletBinding()] 
param( 
   # Alias Name to Register 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $alias, 
   
   # VM NAME 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $vmname,

   # DNS Host Name 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $dnshost,

   # DNS Zone Name 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $dnszone,

   # PowerShell Host Account 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $hostaccount,

   # PowerShell Host Password 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $hostpassword
)

# $finalVmName = $($vmname) + ".hcra.local"
$finalVmName = $($vmname) + "." + $dnszone
Write-host "Main VM is: $($finalVmName)"

# $passwd = ConvertTo-SecureString "VMware1!" -AsPlainText -Force
$passwd = ConvertTo-SecureString $hostpassword -AsPlainText -Force

# $cred = New-Object System.Management.Automation.PSCredential ("hcra.local\svc-vra-admin", $passwd)
$cred = New-Object System.Management.Automation.PSCredential ($hostaccount, $passwd)

Write-Host "Alias to Set: " + $alias + " " + "VM Name is: " + $finalVmName
# $session = New-PsSession -ComputerName "hcra-ad.hcra.local" -Credential $cred
# $session = New-PsSession -ComputerName $dnshost -Credential $cred

Try
{
    $session = New-PsSession -ComputerName $dnshost -Credential $cred
        
    Write-Host "Session Information: $session"
}
Catch
{
    
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName

    Write-Host "Failed Item:  $FailedItem"
    Write-Host "Error Message:  $ErrorMessage"
    exit
}

# Invoke-Command -Session $session -ScriptBlock {Add-DnsServerResourceRecordCName -ComputerName hcra-ad.hcra.local -ZoneName hcra.local -name $Using:alias -HostNameAlias $Using:finalVmName}

#Invoke-Command -Session $session -ScriptBlock {Add-DnsServerResourceRecordCName -ComputerName $Using:dnshost -ZoneName $Using:dnszone -name $Using:alias -HostNameAlias $Using:finalVmName}

if ( ($session.State -eq "Opened") -and ($session.Availability -eq "Available") ) {

    Invoke-Command -Session $session -ScriptBlock {Add-DnsServerResourceRecordCName -ComputerName $Using:dnshost -ZoneName $Using:dnszone -name $Using:alias -HostNameAlias $Using:finalVmName}
}

Remove-PSSession -Session $session


