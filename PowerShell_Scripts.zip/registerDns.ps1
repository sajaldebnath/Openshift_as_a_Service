﻿[CmdletBinding()] 
param( 
   # VM Name to Register 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $vmname, 
   
   # VM IP 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $vmip,

   # DNS Host Name 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $dnshost,

   # DNS Zone Name 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $dnszone,

   # PowerShell Host Account 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $hostaccount,

   # PowerShell Host Password 
   [Parameter(Mandatory=$true)] 
   [ValidateNotNullOrEmpty()] 
   [string] $hostpassword
)

$passwd = ConvertTo-SecureString $hostpassword -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential ($hostaccount, $passwd)

Write-Host "VM Name is: $vmname :: VM IP is: $vmip"

Write-Host "DNS Host Name: $dnshost :: DNS Zone is: $dnszone"

Write-Host "Host Account: $hostaccount "


Try
{
    $session = New-PsSession -ComputerName $dnshost -Credential $cred
        
    Write-Host "Session Information: $session"
}
Catch
{
    
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName

    Write-Host "Failed Item:  $FailedItem"
    Write-Host "Error Message:  $ErrorMessage"
    exit
}


if ( ($session.State -eq "Opened") -and ($session.Availability -eq "Available") ) {

    Invoke-Command -Session $session -ScriptBlock {Add-DnsServerResourceRecordA -ComputerName $Using:dnshost -ZoneName $Using:dnszone -Name $Using:vmname -IPv4Address $Using:vmip -CreatePtr}
}

Remove-PSSession -Session $session
